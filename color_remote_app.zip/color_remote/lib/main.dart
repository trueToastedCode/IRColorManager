import 'package:color_remote/remote.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
  ));
}

class Home extends StatelessWidget {

  final Remote remote = Remote();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF141414),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.invert_colors_on,
                    color: Colors.white,
                    size: 30,
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Color Remote",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: Color(0xFF1e1e1e),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: ListView(
                shrinkWrap: true,
                children: Remote.BUTTONS.map((List<Map<String, dynamic>> buttonRow) => Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: buttonRow.map((Map<String, dynamic> button) => ColorButtonTemplate(
                      button: button,
                      remote: remote,
                    )).toList(),
                  ),
                )).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ColorButtonTemplate extends StatelessWidget {
  final Map<String, dynamic> button;
  final Remote remote;

  ColorButtonTemplate({@required this.button, @required this.remote});

  Color getColor() => button.containsKey(Remote.KEY_SHOW_COLOR)
      ? Color(button[Remote.KEY_SHOW_COLOR])
      : Colors.black;

  Widget getShow(dynamic pShow) {
    if (pShow is String) return Text(
      button[Remote.KEY_SHOW],
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: button[Remote.KEY_SHOW].length == 1 ? 18 : 15,
          color: getColor(),
      ),
      maxLines: 1,
    );
    if (pShow is IconData) return Icon(
      pShow,
      size: 30,
      color: getColor(),
    );
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 65,
      height: 65,
      child: RawMaterialButton(
        onPressed: () => remote.pressButton(button[Remote.KEY_BUTTON]),
        fillColor: Color(button[Remote.KEY_COLOR]),
        shape: CircleBorder(),
        splashColor: Colors.blue,
        child: getShow(button[Remote.KEY_SHOW]),
      ),
    );
  }
}
