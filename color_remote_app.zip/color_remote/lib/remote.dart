import 'package:flutter/material.dart';
import 'package:http/http.dart';

class Remote {
  static const String ADDRESS = "http://192.168.0.10:8080/color-button";

  static const String
    KEY_COLOR = "color",
    KEY_SHOW = "text",
    KEY_SHOW_COLOR = "showColor",
    KEY_BUTTON = "button";

   static const List<List<Map<String, dynamic>>> BUTTONS = [
    [
      {
        KEY_COLOR: 0xFFFFFFFF,
        KEY_SHOW: "B",
        KEY_BUTTON: "1",
      },
      {
        KEY_COLOR: 0xFFFFFFFF,
        KEY_SHOW: "D",
        KEY_BUTTON: "2",
      },
      {
        KEY_COLOR: 0xFF000000,
        KEY_SHOW: Icons.offline_bolt_outlined,
        KEY_SHOW_COLOR : 0xFFFFFFFF,
        KEY_BUTTON: "3",
      },
      {
        KEY_COLOR: 0xFFCC0000,
        KEY_SHOW: Icons.offline_bolt_sharp,
        KEY_SHOW_COLOR : 0xFFFFFFFF,
        KEY_BUTTON: "4",
      }
    ],
    [
      {
        KEY_COLOR: 0xFFCC0000,
        KEY_SHOW: "R",
        KEY_BUTTON: "5",
      },
      {
        KEY_COLOR: 0xFF00471A,
        KEY_SHOW: "G",
        KEY_BUTTON: "6",
      },
      {
        KEY_COLOR: 0xFF0F3575,
        KEY_SHOW: "B",
        KEY_BUTTON: "7",
      },
      {
        KEY_COLOR: 0xFFFFFFFF,
        KEY_SHOW: "W",
        KEY_BUTTON: "8",
      }
    ],
    [
      {
        KEY_COLOR: 0xFFB34B25,
        KEY_SHOW: null,
        KEY_BUTTON: "9",
      },
      {
        KEY_COLOR: 0xFF00541f,
        KEY_SHOW: null,
        KEY_BUTTON: "10",
      },
      {
        KEY_COLOR: 0xFF11569F,
        KEY_SHOW: null,
        KEY_BUTTON: "11",
      },
      {
        KEY_COLOR: 0xFF35414F,
        KEY_SHOW: "FLASH",
        KEY_BUTTON: "12",
      }
    ],
    [
      {
        KEY_COLOR: 0xFFAC621B,
        KEY_SHOW: null,
        KEY_BUTTON: "13",
      },
      {
        KEY_COLOR: 0xFF0A829B,
        KEY_SHOW: null,
        KEY_BUTTON: "14",
      },
      {
        KEY_COLOR: 0xFF46295D,
        KEY_SHOW: null,
        KEY_BUTTON: "15",
      },
      {
        KEY_COLOR: 0xFF35414F,
        KEY_SHOW: "STROBE",
        KEY_BUTTON: "16",
      }
    ],
    [
      {
        KEY_COLOR: 0xFFC0981D,
        KEY_SHOW: null,
        KEY_BUTTON: "17",
      },
      {
        KEY_COLOR: 0xFF037593,
        KEY_SHOW: null,
        KEY_BUTTON: "18",
      },
      {
        KEY_COLOR: 0xFF6C3A6B,
        KEY_SHOW: null,
        KEY_BUTTON: "19",
      },
      {
        KEY_COLOR: 0xFF35414F,
        KEY_SHOW: "FADE",
        KEY_BUTTON: "20",
      }
    ],
    [
      {
        KEY_COLOR: 0xFFC3BA00,
        KEY_SHOW: null,
        KEY_BUTTON: "21",
      },
      {
        KEY_COLOR: 0xFF1A6E7F,
        KEY_SHOW: null,
        KEY_BUTTON: "22",
      },
      {
        KEY_COLOR: 0xFFB56A90,
        KEY_SHOW: null,
        KEY_BUTTON: "23",
      },
      {
        KEY_COLOR: 0xFF35414F,
        KEY_SHOW: "SMOOTH",
        KEY_BUTTON: "24",
      }
    ]
  ];

  void pressButton(String pButton) async {
    await post(ADDRESS, body: {KEY_BUTTON: pButton});
  }
}